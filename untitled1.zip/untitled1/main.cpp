#include <windows.h>

ิbool ReadBmp( HBITMAP *hBmp, LPCTSTR fname )
{
    *hBmp = (HBITMAP)LoadImage(
            NULL,         //หมายเลขอ้างอิงหน้าต่าง(ค่าเริ่มต้นเป็น NULL)
            fname,        //ชื่อไฟล์ภาพ
            IMAGE_BITMAP, //ระบุภาพบิตแมป(คงที่)
            0, 0,         //พิกัดเริ่มต้นของภาพพื้นหลัง
            LR_LOADFROMFILE); //อ่านภาพจากไฟล์
    if(*hBmp == NULL )
    {       //ตารางการประมวลผลข้อความผิดพลาด
        MessageBox( NULL, "Can not setup the screen windows", fname, MB_OK );
        return false;
    }
    return true;
}
 //ตั้งฟังชั่นในหน้าต่าง
LRESULT CALLBACK WindowProc(
        HWND   hWnd,   //การจัดการหน้าต่าง
        UINT   uMsg,   //กระดานข้อความ
        WPARAM  wParam, //ข้อมูลที่เกี่ยวข้องของข้อความ
        LPARAM  lParam ) //ข้อมูลที่เกี่ยวข้องของข้อความ
{
    //ประกาศตัวแปร
    HDC hdc;                //ฉากที่แสดงในหน้าต่าง
    PAINTSTRUCT ps;         //โครงสร้างภาพ
    static HDC hMemDC;      //หน่วยความจำ
    static HBITMAP hBack;   //ฟังชั่นการประมวลผลภาพ(ภาพเป็นแนวตั้ง)

    static HFONT hFont;     //กำหนดขนาดตัวอักษรในการสนทนา

    static HBITMAP hTitle;
    static int scene = 0;

    //ตั้งฟังชั่น
    switch (uMsg)
    {
        case WM_DESTROY:  //เมื่อหน้าต่างแจ้งเตือนสิ้นสุดลง(ตั้งค่าหมายเลขอ้างอิงสุดท้าย)
            DeleteObject(hBack); //ฟังชั่งออกจากการปะมวลผลภาพ
            DeleteObject(hMemDC); //ออกจากหน่วยความจำ

            PostQuitMessage(0); //ประกาศปิดหน้าต่าง
            return 0;

        case WM_CREATE: // สร้างหน้าต่าง(ตั้งค่าการประมวลผลเริ่มต้น)
            //ชุดตัวอักษรของบทสนทนา
            hFont = CreateFont(
                    40,            //ขนาดตัวอักษรขนาดใหญ่
                    20,            //ความขนาดตัวอักษร
                    0,             //มุมมอง
                    0,             //มุมฐาน
                    FW_REGULAR,    //ความกล้าหาญของคำ
                    FALSE,         //ตัวเอียง(false = not set)
                    FALSE,         //ขีดเส้นใต้
                    FALSE,         //เส้นประ
                    SHIFTJIS_CHARSET, //ชุดตัวละคร
                    OUT_DEFAULT_PRECIS,  //ความแม่นยำในการส่งออก
                    CLIP_DEFAULT_PRECIS, //ความแม่นยำของคลิปที่ถูกต้อง
                    DEFAULT_QUALITY,     //คุณภาพผลผลิต
                    VARIABLE_PITCH | FF_ROMAN,  //ระดับชุดตัวแปร , ชุดตัวแปร
                    "Arial");   //ฟ้อนที่ใช้

            if( !ReadBmp( &hBack,".bmp")) return 0;


            hMemDC = CreateCompatibleDC(NULL);
            return 0;

        case WM_KEYDOWN:

            switch(wParam){
                case VK_ESCAPE:
                    PostQuitMessage(0);
                    break;

                case VK_RETURN:
                    scene++;
                    break;
            }

            InvalidateRect( hWnd, NULL, FALSE);

            return 0;

            case WM_PAINT:  //เมื่อแสดงภาพ
            hdc = BeginPaint(hWnd, &ps);  //ตั้งภาพแรก
            //หน่วยคำจำชั่วคราวเพื่อแสดงภาพ
            SelectObject(hMemDC, hBack); //หน่วยความจำช่ั่วคราวเพื่อแสดงภาพ

            BitBlt(
                    hdc,       //หน้าเจอหน้าตาม
                    0,0,       //เริ่มต้นพิกัด x, y
                    640,480,   //ความกว้างแล้วความสูงของแสง
                    hMemDC,    //หน่วยความจำ
                    0,0,       //กำหนด พิกัด X,Y บนภาพ
                    SRCCOPY);   //คัดลอกภาพจากหน่วยความจำภายใน
            //ตั้งค่าแบบอักษรบนหน้าจอ
            SelectObject(hdc, hFont);
            //เปลี่ยนสีพื้นหลังของการสนทนา
            SetTextColor(hdc,RGB(, , ,));
            //ตั้งค่าสีพื้นหลังโปร่งใส่
            SetBkColor(hdc,TRANSPARENT);
                //ลบผลของ(ตั้งค่าสีพื้นหลังโปร่งใส่)
            SetBkColor(hdc, OPAQUE);
            //ข้อความที่แสดง
            TextOut(
                    hdc,         //จอภาพ
                    10, 50,      //เริ่มต้น x,y พิกัดของข้อความ
                    "Hello",     //แสดงสายเสียง
                    lstrlen("Hello")); //ความยาวของประโยคจะปรากฎขึ้น

            EndPaint(hWnd, &ps ); //แสดงภาพสุดท้าย
            return 0;
    }
     //ข้อมูลที่ถูกส่งคืนไปยังโปรแกรม
    return DefWindowProc( hWnd, uMsg, wParam, lParam );

}

int WINAPI WinMain(
        HINSTANCE hInstance,  //จำนวนหน้าต่างwindows
        HINSTANCE hPrevInstance,   //
        PSTR IpCmdLine,
        int nCmdShow )
{

    WNDCLASS wc;  //โครงสร้างของเลเยอร์หน้าจอ windows
    HWND  hWnd;   //ฟังชั่นของ windows number
    MSG msg;      //กล่องโต้ตอบการแจ้งเตือน

                //--หน้าต่างข้อมูลถูกสร้างขึ้น--//

    wc.style = CS_HREDRAW | CS_VREDRAW; // ชื่อหน้าต่าง
    wc.lpfnWndProc = DefWindowProc;  //สร้างชื่อพื้นที่ฟังชั่น
    wc.cbClsExtra = 0;   //ดัชนีคงทีคือ 0
    wc.cbWndExtra = 0;   //ดัชนีคงทีคือ 0
    wc.hInstance = hInstance; //จำนวนหน้าต่าง windows
    wc.hIcon = NULL; // ตั่งค่าไอคอนโปรแกรม
    wc.hCursor = NULL;  //ตั้งค่าการควบคุมพื้นหลัง
    wc.hbrBackground =(HBRUSH)COLOR_BACKGROUND+1; //สีพื้นหลังของหน้าต่าง
    wc.lpszMenuName = NULL;
    wc.lpszClassName = "MainWindow"; //สร้างชื่อโปรแกรม
    //สร้างหน้าต่างกระดานข่าว
    if(!RegisterClass(&wc))
    {
        //ข้อความแสดงข้อผิดพลาดเมื่อไม่ได้ตั่งค่า windows
        MessageBox( NULL, "Can not setup the screen window", "Error", MB_OK );
        return 0;
    }
    //การตั้งค่า windows
    hWnd = CreateWindow(
            "MainWindows",   //สร้างชื่อโปรแกรม
            "Makagon Road",  //ชื่อเกมส์ บนwindows
            WS_OVERLAPPEDWINDOW, //หน้าต่างทั่วไป
            100, 100,     //แสดงตำแหน่งพิกัด x , y
            640, 480,     //ความกว้างความสูง
            NULL,         //จัดการหน้าต่าง (ค่าเริ่มต้นเป็นโมฆะ)
            NULL,         //การตั่งค่าเมนู (NULL = เมนูที่ไม่ได้ใช้)
            hInstance,
            NULL);        //ข้อมูลที่สร้างขึ้นในระหว่างการสร้าง

    if(hWnd == NULL )    //number windows(ค่าNULLเริ่มต้น)+
    {
            //ข้อความแสดงข้อผิดพลาดเมื่อไม่สามารถด้ังค่าหน้าจอได้
        MessageBox( NULL,"Can Not setup the screen windows","Error", MB_OK );
        return 0;
    }
    //หน้าต่างแสดงผล
    ShowWindow( hWnd, SW_SHOW );
     //แจ้งให้ทราบล่วงหน้า(สร้างลูปจนกว่าหน้าต่างจะปิด)
    while(GetMessage( &msg, NULL, 0, 0)> 0) //สร้างการแจ้งเตือนไปยังหน้าต่าง
    {
        //ส่งข้อความแจ้งเตือนไปที่หน้าต่าง
        DispatchMessage( &msg );
    }
    return 0;
}